from sqlalchemy.orm import Session
from services.vector_store import VectorStore
from services.llm_service import generate_response
from services.cache_manager import CacheManager
from models.document import Document 

class QuestionHandler:
    def __init__(self):
        self.vector_store = VectorStore()
        self.cache = CacheManager()

    def get_answer(self, question: str, db: Session):
        cached_answer = self.cache.get(question)
        if cached_answer:
            return {**cached_answer, "cached": True}
        search_results = self.vector_store.find_similar_chunks(question, n_results=5)
        
        if not search_results or not search_results.get("documents") or not search_results["documents"][0]:
             return {
                "question": question,
                "answer": "Désolé, je n'ai trouvé aucune information pertinente dans les documents fournis.",
                "sources": [],
                "cached": False
            }

        documents_content = search_results["documents"][0]
        metadatas = search_results["metadatas"][0]
        context_parts = []
        for i, doc_text in enumerate(documents_content):
            meta = metadatas[i]
            filename = meta.get("filename", "Document inconnu")
            page = meta.get("page", "?")
            context_parts.append(f"--- SOURCE : {filename} (Page {page}) ---\nCONTENU : {doc_text}")

        full_context = "\n\n".join(context_parts)
        answer = generate_response(question, full_context)

        sources = []
        
        doc_ids = {meta.get("document_id") for meta in metadatas if meta.get("document_id") is not None}
        db_docs = db.query(Document).filter(Document.id.in_(doc_ids)).all()
        db_titles = {doc.id: doc.file_name for doc in db_docs}
        
        for meta in metadatas:
            doc_id = meta.get("document_id")
            final_title = db_titles.get(doc_id, meta.get("filename", "Document inconnu"))
            
            sources.append({
                "document": final_title, 
                "page": meta.get("page")
            })

        final_response = {
            "question": question,
            "answer": answer,
            "sources": sources
        }

        self.cache.set(question, final_response)
        return {**final_response, "cached": False}