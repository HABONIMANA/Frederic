import chromadb
from sentence_transformers import SentenceTransformer
from typing import List, Dict
import os
import time

class VectorStore:
    _model_instance = None  
    _client_instance = None 

    def __init__(self):
        # Configuration des chemins
        base_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        db_path = os.path.join(base_dir, "data", "chroma_db")
        
        # 1. Initialisation unique du client DB
        if VectorStore._client_instance is None:
            print(f"📂 Connexion à ChromaDB sur : {db_path}")
            VectorStore._client_instance = chromadb.PersistentClient(path=db_path)
        self.client = VectorStore._client_instance

        # 2. Initialisation unique du modèle IA (Le plus critique pour la vitesse)
        if VectorStore._model_instance is None:
            print("⏳ Chargement du modèle d'embedding (ceci ne doit arriver qu'une fois)...")
            start_time = time.time()
            # Utilisation de 'device="cpu"' explicite pour éviter les erreurs si pas de GPU
            VectorStore._model_instance = SentenceTransformer('intfloat/multilingual-e5-small', device="cpu")
            print(f"✅ Modèle chargé en {time.time() - start_time:.2f} secondes.")
        
        self.embedding_model = VectorStore._model_instance
        
        # Récupération ou création de la collection
        self.collection = self.client.get_or_create_collection(
            name="documents",
            metadata={"hnsw:space": "cosine"} 
        )

    def add_document_chunks(self, doc_id: int, chunks: List[Dict]):
        if not chunks:
            return

        print(f"⚙️ Calcul des embeddings pour {len(chunks)} chunks...")
        start_time = time.time()

        texts = [chunk["text"] for chunk in chunks]
        # Le modèle e5 demande le préfixe "passage: " pour les documents
        prefixed_texts = [f"passage: {text}" for text in texts]
        
        # Calcul des embeddings
        embeddings = self.embedding_model.encode(prefixed_texts, normalize_embeddings=True)
        print(f"⚡ Embeddings calculés en {time.time() - start_time:.2f}s")

        metadatas = []
        for i, chunk in enumerate(chunks):
            meta = chunk["metadata"].copy()
            meta["document_id"] = doc_id
            meta["chunk_index"] = i
            metadatas.append(meta)
            
        ids = [f"doc_{doc_id}_chunk_{i}" for i, _ in enumerate(chunks)]

        self.collection.add(
            embeddings=embeddings.tolist(),
            metadatas=metadatas,
            documents=texts,  
            ids=ids
        )
        print(f"✅ Sauvegarde terminée pour le document {doc_id}.")

    def find_similar_chunks(self, question: str, n_results: int = 5) -> Dict:
        """Trouve les chunks pertinents."""
        
        prefixed_question = f"query: {question}"
        
        query_embedding = self.embedding_model.encode(prefixed_question, normalize_embeddings=True)
        
        results = self.collection.query(
            query_embeddings=[query_embedding.tolist()],
            n_results=n_results,
            include=["documents", "metadatas", "distances"]  
        )
        
        return results