import os
from groq import Groq
from openai import OpenAI
import google.generativeai as genai
from dotenv import load_dotenv

load_dotenv()

LLM_PROVIDER = os.getenv("LLM_PROVIDER", "groq").lower()
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")

def generate_response(question: str, context: str) -> str:
    """Génère une réponse stricte basée sur le contexte."""
    
    prompt = f"""
    RÔLE :
    Tu es "L'Assistant Éducatif", un expert pédagogique qui aide les étudiants à comprendre leurs cours.

    CONSIGNES DE SÉCURITÉ :
    1. Réponds UNIQUEMENT avec les infos du CONTEXTE.
    2. Si l'info manque, dis : "Je ne trouve pas l'information dans les documents."
    
    CONSIGNES DE RÉDACTION :
    3. Sois concis (max 150 mots).
    4. CITE TES SOURCES : [Nom_Fichier, Page X].
    5. ADAPTATION LINGUISTIQUE : Réponds TOUJOURS dans la même langue que la question de l'utilisateur (Si question en Anglais -> Réponse Anglais).

    CONTEXTE FOURNI :
    {context}

    QUESTION DE L'ÉTUDIANT :
    {question}

    RÉPONSE :
    """

    current_provider = LLM_PROVIDER
    
    if current_provider == "groq" and not GROQ_API_KEY:
        if OPENAI_API_KEY: current_provider = "openai"
        elif GOOGLE_API_KEY: current_provider = "google"

    try:
        if current_provider == "groq":
            return _call_groq(prompt)
        elif current_provider == "openai":
            return _call_openai(prompt)
        elif current_provider == "google":
            return _call_google(prompt)
        else:
            return "Erreur : Aucun fournisseur configuré."
            
    except Exception as e:
        return f"Erreur technique : {str(e)}"

def _call_groq(prompt):
    client = Groq(api_key=GROQ_API_KEY)
    chat_completion = client.chat.completions.create(
        messages=[{"role": "user", "content": prompt}],
        model="llama-3.3-70b-versatile",
        temperature=0.1
    )
    return chat_completion.choices[0].message.content

def _call_openai(prompt):
    client = OpenAI(api_key=OPENAI_API_KEY)
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.1
    )
    return response.choices[0].message.content

def _call_google(prompt):
    genai.configure(api_key=GOOGLE_API_KEY)
    model = genai.GenerativeModel('gemini-1.5-flash')
    response = model.generate_content(prompt)
    return response.text